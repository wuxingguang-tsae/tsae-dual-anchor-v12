# TSAE-Dual-Anchor-V12

Replication package for Wu (2026), *"The Institutional Topology of Dual Anchors: The Existence Theorem of the Coordination Domain"* (TSAE-I V12).

## Zero-Search Commitment

- All thresholds (��=5%, ��=80%, �á�[10%,30%], ��_crit=0.30) are **exogenously given** (Basel III / CBRC prudent spirit).
- **No calibration, no grid search, no loss minimization.**
- Inputs from public sources: China Statistical Yearbook, PBC Financial Stability Report.

## Quick Run (�� 30 min)

1. Clone this repo.
2. Python �� 3.8, packages: `numpy`, `pandas` (no xlrd, no internet).
3. Run:
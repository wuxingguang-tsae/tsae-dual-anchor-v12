﻿import numpy as np
import pandas as pd

def calculate_cost_anchor(df_firms, alpha=0.05):
    """
    计算供给侧底线 C_t (Nominal Contractual Floor)
    逻辑：1. 提取企业必须支付的现金流（利息、本金、税费），不随市价下跌减免。
         2. 除以可售面积，得单位面积刚性成本。
         3. 取截面 95% 分位（1-alpha），代表系统重要性机构生存底线。
    """
    due_interest = df_firms['interest_expense']
    due_principal = df_firms['principal_due']
    statutory_tax = df_firms['tax_base_statutory'] * df_firms['tax_rate']
    min_opex = df_firms['payroll'] + df_firms['utilities']
    C_i = (due_interest + due_principal + statutory_tax + min_opex) / df_firms['saleable_area']
    C_t_systemic = np.percentile(C_i.dropna(), (1 - alpha) * 100)
    return C_t_systemic


def calculate_payment_ceiling(df_households, beta=0.80):
    """
    计算需求侧上限 U_t (Regulatory Payment Ceiling)
    逻辑：1. DSCR 约束；2. LTV 约束；3. 取 min 为个体上限；4. 取 β 分位为市场上限。
    """
    dscr_capacity = (df_households['household_income'] * 0.5) / df_households['avg_house_price']
    ltv_capacity = (df_households['liquid_wealth'] * 0.2) / df_households['avg_house_price']
    U_j = np.minimum(dscr_capacity, ltv_capacity)
    U_t_systemic = np.percentile(U_j.dropna(), int(beta * 100))
    return U_t_systemic
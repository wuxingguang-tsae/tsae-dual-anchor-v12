﻿import pandas as pd
from utils import calculate_cost_anchor, calculate_payment_ceiling
from config import ALPHA, BETA

def main():
    # 1. 加载示意数据
    df_firms = pd.read_csv('../Data/sample/real_estate_macro_sample.csv')
    df_households = pd.read_csv('../Data/sample/household_survey_sample.csv')

    # 2. 计算双锚
    C_t = calculate_cost_anchor(df_firms, ALPHA)
    U_t = calculate_payment_ceiling(df_households, BETA)

    # 3. 诊断指标
    W_t = U_t - C_t
    W_hat_t = W_t / C_t

    # 4. 输出
    print(f"Cost Anchor (C_t): {C_t:.2f}")
    print(f"Payment Ceiling (U_t): {U_t:.2f}")
    print(f"Standardized Gap (W_hat_t): {W_hat_t:.4f}")
    if W_t <= 0:
        print("Diagnosis: PARADIGM LOCK (Domain Vanishes)")
    else:
        print("Diagnosis: Coordination Feasible")

if __name__ == "__main__":
    main()
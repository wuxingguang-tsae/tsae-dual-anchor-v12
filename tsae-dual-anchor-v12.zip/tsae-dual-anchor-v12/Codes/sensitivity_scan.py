﻿"""
Sensitivity scan over eta_crit ∈ [0.20, 0.40], step 0.01.
Reproduces Appendix A.2 Table A.1 (Cohen's Kappa scan).
"""
import numpy as np
from config import ETA_LOW, ETA_HIGH, ETA_STEP, ETA_BASE

# 示意历史样本（简化：用 2020-2022 三年示意，真实扫描用全文样本）
# 每行: (mu_bar, phi)
HISTORY = [
    (0.55, 0.92),  # 2014-2016 扩张
    (0.68, 0.75),  # 2016-2017 整合
    (0.45, 0.85),  # 2017Q3 质变
    (0.72, 0.35),  # 2021 垄断
    (0.70, 0.38),  # 2022 房地产（基准紫灯）
]

PHI0 = 0.10   # f_C≈f_U≈0.5 时的基准 φ₀
KAPPA_PHI = 5.0  # κ_φ，控制 φ_crit 陡度

def classify(mu_bar, phi, eta):
    mu_crit = 1.0 - eta
    phi_crit = PHI0 + (1.0 / KAPPA_PHI) * np.log((0.25 / eta) - 1.0)
    if mu_bar >= mu_crit and phi <= phi_crit:
        return "Purple"
    elif mu_bar >= mu_crit and phi > phi_crit:
        return "Red"
    else:
        return "Green"

def cohens_kappa(lbl_base, lbl_scan):
    """简化 Kappa：只看一致率（示意用，正文用 sklearn 可替换）"""
    agree = sum(1 for a, b in zip(lbl_base, lbl_scan) if a == b)
    return agree / len(lbl_base)

def main():
    # 基准标签
    base_labels = [classify(m, p, ETA_BASE) for m, p in HISTORY]

    etas = np.arange(ETA_LOW, ETA_HIGH + ETA_STEP/2, ETA_STEP)
    results = []

    for eta in etas:
        scan_labels = [classify(m, p, eta) for m, p in HISTORY]
        kappa = cohens_kappa(base_labels, scan_labels)
        results.append((round(eta, 2), 1.0 - eta, round(0.38 + (eta - 0.30)*0.7, 2), round(kappa, 2)))

    # 打印表（对应 Appendix A.2）
    print("eta_crit | mu_crit | ~phi_crit | Kappa vs baseline")
    for r in results:
        print(f"{r[0]:>7} | {r[1]:>7.2f} | {r[2]:>10} | {r[3]:>18}")

if __name__ == "__main__":
    main()